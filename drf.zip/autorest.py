# coding=UTF-8
import  getopt
import  sys
import  os
import  re

## 获取参数




def walkFile(file):
    for root, dirs, files in os.walk(file):

        # root 表示当前正在访问的文件夹路径
        # dirs 表示该文件夹下的子目录名list
        # files 表示该文件夹下的文件list

        newdict=[]  ##返回文件夹跟文件名的数组

        # 遍历文件
        for f in files:
            temp={}
            temp["dir"]=root.split('/')[2]
            temp["filename"]=f
            newdict.append(temp)
        return  newdict

            # print(os.path.join(root, f))




def write(dirname,filename,orfile,mdir,nocap):  ##目录名同时作为函数名来进行导入

    f1 = open(orfile)
    content = f1.read()
    os.mkdir(dirname)
    with open("%s/%s"%(dirname,filename), 'w') as f:
        if  nocap:
            f.write(content%(dirname))
        else:
            print dirname.capitalize()
            f.write(content%(dirname.capitalize()))


# def  gen():
#     clname = sys.argv[1]
#     dict=walkFile("./temp/")
#     for i in dict:
#         if i['dir']=="":
#             if i['filename']=="apps.txt":
#                 write(clname,i['filename'],"./temp/%s%s"%(i['dir'],i["filename"]),False,True)
#             else:
#                 write(clname,i['filename'],"./temp/%s%s"%(i['dir'],i["filename"]),False,False)
#         else:
#             write(clname, i['filename'], "./temp/%s%s" % (i['dir'], i["filename"]), True,False)

def gen():
    clname = sys.argv[1]
    write(clname, "apps.txt", "./temp/%s%s" % ("", "apps.txt"), False, True)


##app模块单独处理 其他循环遍历
# write("test2","serializers","temp/rest/serializers.txt")
gen()






