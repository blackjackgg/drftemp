# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models



# Create your models here.
class %s(models.Model):

    class Meta:  ##独立新表
        db_table= %s
        verbose_name = %s


    def __str__(self):
        return self







